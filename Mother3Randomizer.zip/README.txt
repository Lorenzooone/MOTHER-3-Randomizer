This is the MOTHER 3 Randomizer!

To execute it in Windows, double click on the M3RandomizerWindows.exe file!

To execute it in Linux, open the Terminal, navigate to the directory where these files are
and use the following command: "./M3RandomizerLinux", without the "!

To execute it in MacOS, open the Terminal, navigate to the directory where these files are
and use the following command: "./M3RandomizerMacOS", without the "!

To contact me on Twitter: https://twitter.com/Lorenzooone